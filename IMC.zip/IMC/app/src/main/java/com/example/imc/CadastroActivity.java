package com.example.imc;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CadastroActivity extends AppCompatActivity {

    private SQLiteDatabase db;
    private EditText editNome, editPeso, editAltura;
    private Button btnSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        editNome = findViewById(R.id.editNome);
        editPeso = findViewById(R.id.editPeso);
        editAltura = findViewById(R.id.editAltura);
        btnSalvar = findViewById(R.id.btnSalvar);

        // Abrir ou criar o banco de dados
        db = openOrCreateDatabase("app", MODE_PRIVATE, null);

        btnSalvar.setOnClickListener(v -> salvarDados());
    }

    private void salvarDados() {
        String nome = editNome.getText().toString();
        double peso;
        double altura;

        try {
            peso = Double.parseDouble(editPeso.getText().toString());
            altura = Double.parseDouble(editAltura.getText().toString());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Peso e altura devem ser números", Toast.LENGTH_SHORT).show();
            return;
        }

        double imc = calcularIMC(peso, altura);
        String interpretacao = interpretarIMC(imc);

        // Salvar os dados no banco de dados
        salvarNoBanco(nome, peso, altura, imc, interpretacao);

        // Exibir o IMC e a interpretação usando Toast
        Toast.makeText(
                this,
                "IMC: " + String.format("%.2f", imc) + "\n" + interpretacao,
                Toast.LENGTH_LONG
        ).show();

        // Fechar a Activity e voltar à listagem
        finish();
    }

    private double calcularIMC(double peso, double altura) {
        return peso / (altura * altura);
    }

    private String interpretarIMC(double imc) {
        if (imc < 18.5) {
            return "Abaixo do peso";
        } else if (imc < 24.9) {
            return "Peso normal";
        } else if (imc < 29.9) {
            return "Sobrepeso";
        } else {
            return "Obesidade";
        }
    }

    private void salvarNoBanco(String nome, double peso, double altura, double imc, String interpretacao) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("nome", nome);
        contentValues.put("peso", peso);
        contentValues.put("altura", altura);
        contentValues.put("imc", imc);
        contentValues.put("interpretacao", interpretacao);

        long result = db.insert("DADOS", null, contentValues);

        if (result == -1) {
            Toast.makeText(this, "Erro ao salvar os dados", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Dados salvos com sucesso!", Toast.LENGTH_SHORT).show();
        }
    }
}