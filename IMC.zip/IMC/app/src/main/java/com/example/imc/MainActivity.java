package com.example.imc;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private SQLiteDatabase db;
    private ListView listViewPessoas;
    private Button btnCadastrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listViewPessoas = findViewById(R.id.listViewPessoas);
        btnCadastrar = findViewById(R.id.botaoCadastrar);

        // Criação ou abertura do banco de dados
        db = openOrCreateDatabase("app", MODE_PRIVATE, null);

        // Criação da tabela de pessoas
        db.execSQL("CREATE TABLE IF NOT EXISTS DADOS (" +
                "iddado INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nome VARCHAR, " +
                "peso REAL, " +
                "altura REAL, " +
                "imc REAL, " +
                "interpretacao VARCHAR)");

        // Listar os dados na ListView
        listarDados();

        // Ação do botão de cadastro para abrir a Activity de cadastro
        btnCadastrar.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CadastroActivity.class);
            startActivity(intent);
        });
    }

    private void listarDados() {
        // Consulta para buscar os dados
        Cursor cursor = db.rawQuery("SELECT nome, imc, interpretacao FROM DADOS", null);

        // Lista para armazenar os dados formatados
        List<String> itens = new ArrayList<>();

        // Iterar sobre o cursor e criar as strings no formato "nome - imc - interpretação"
        if (cursor.moveToFirst()) {
            do {
                String nome = cursor.getString(cursor.getColumnIndexOrThrow("nome"));
                double imc = cursor.getDouble(cursor.getColumnIndexOrThrow("imc"));
                String interpretacao = cursor.getString(cursor.getColumnIndexOrThrow("interpretacao"));

                // Adicionar a string formatada à lista
                itens.add(nome + " - " + String.format("%.2f", imc) + " - " + interpretacao);
            } while (cursor.moveToNext());
        }

        // Fechar o cursor
        cursor.close();

        // Criar o ArrayAdapter com os itens formatados
        ArrayAdapter<String> adaptador = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1, // Layout simples do Android
                itens
        );

        // Definir o adaptador no ListView
        listViewPessoas.setAdapter(adaptador);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Atualizar a listagem quando voltar da tela de cadastro
        listarDados();
    }
}